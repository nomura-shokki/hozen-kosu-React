document.addEventListener('DOMContentLoaded', function() {
    const updateButton = document.getElementById('update');
    if (updateButton) {
    updateButton.click();
    }
});