document.getElementById('work_day').addEventListener('change', function() {
    document.getElementById('update').click();
});